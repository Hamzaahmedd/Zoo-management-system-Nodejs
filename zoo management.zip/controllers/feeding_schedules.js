'use strict';
const { Animal, Food_item, Feeding_schedule } = require('../models');

// GET all Feeding Schedules
const getAllFeedingSchedules = async (req, res) => {
    try {                         
            const feedingSchedules = await Feeding_schedule.findAll({
            include: [
                { model: Food, as: 'food' },
                { model: Animal, as: 'animal' }                             
            ]
        });

        if (!feedingSchedules || feedingSchedules.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Feeding Schedules',
            totalFeedingSchedules: feedingSchedules.length,
            data: feedingSchedules
        });

    } catch (error) {
        console.error('Error in GET all feedingSchedules API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all feedingSchedules API',
            error: error.message
        });
    }
};

// GET FeedingSchedule by ID
const getFeedingScheduleByID = async (req, res) => {
    const feedingScheduleID = req.params.id;
    if (!feedingScheduleID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const feedingSchedule = await Feeding_schedule.findByPk(feedingScheduleID, {
            include: [
                { model: Food, as: 'food' },
                { model: Animal, as: 'animal' }
            ]
        });

        if (!feedingSchedule) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Feeding Schedule not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Feeding schedule Details',
            feedingScheduleDetails: feedingSchedule
        });

    } catch (error) {
        console.error('Error in GET feedingSchedules by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET feedingSchedules by ID API',
            error: error.message
        });
    }
};

// CREATE FeedingSchedule
const createFeedingSchedule = async (req, res) => {
    const { animal_id, time, food_id, status } = req.body;

    try {
        // Check if the animal_id exists
        const animal = await Animal.findByPk(animal_id);
        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'animal_id not found'
            });
        }

        // Check if the food_id exists
        const food = await Food_item.findByPk(food_id);
        if (!food) {
            return res.status(404).json({
                success: false,
                message: 'food_id not found'
            });
        }

        // Create new user using Sequelize create method
        const newFeedingSchedule = await Feeding_schedule.create({animal_id, time, food_id, status});

        res.status(201).json({
            success: true,
            message: 'New Feeding Schedule created',
            data: newFeedingSchedule
        });

    } catch (error) {
        console.error('Error in CREATE feeding schedule API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE feeding schedule API',
                error: error.message
            });
          } 
    }
};

// UPDATE FeedingSchedule
const updateFeedingSchedule = async (req, res) => {
    const feedingScheduleID = req.params.id;
    if (!feedingScheduleID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { animal_id, time, food_id, status } = req.body;

    try {
        // Check if the feeding schedule ID exists
        const feedingSchedule = await Feeding_schedule.findByPk(feedingScheduleID);
        if (!feedingSchedule) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Feeding Schedule not found'
            });
        }

        // Check if the animal_id exists
        const animal = await Animal.findByPk(animal_id);
        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'animal_id not found'
            });
        }

        // Check if the food_id exists
        const food = await Food_item.findByPk(food_id);
        if (!food) {
            return res.status(404).json({
                success: false,
                message: 'food_id not found'
            });
        }

        // Update the feeding schedule record using Sequelize
    await feedingSchedule.update({animal_id, time, food_id, status});

        return res.status(200).json({
            success: true,
            message: 'Feeding Schedule details updated',
            data: feedingSchedule
        });

    } catch (error) {
        console.error('Error in UPDATE feeding schedule API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE feeding schedule API',
                error: error.message
            });
          } 
    }
};

// PATCH FeedingSchedule
const patchFeedingSchedule = async (req, res) => {
    const feedingScheduleID = req.params.id;
    if (!feedingScheduleID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { animal_id, time, food_id, status } = req.body;

    try {
         // Check if the feeding schedule ID exists
         const feedingSchedule = await Feeding_schedule.findByPk(feedingScheduleID);
         if (!feedingSchedule) {
             return res.status(404).json({
                 success: false,
                 message: 'Invalid ID. Feeding Schedule not found'
             });
         }

        const fieldsToUpdate = {};

        if (animal_id) {
            // Check if the animal_id exists
        const animal = await Animal.findByPk(animal_id);
        if (!animal) {
            return res.status(404).json({
                success: false,
                message: 'animal_id not found'
            });
        }

            fieldsToUpdate.animal_id = animal_id;
        }

        if (time) {
            fieldsToUpdate.species = species;
        }

        if (food_id) {
         // Check if the food_id exists
         const food = await Food_item.findByPk(food_id);
         if (!food) {
             return res.status(404).json({
                 success: false,
                 message: 'food_id not found'
             });
         }
            fieldsToUpdate.food_id = food_id;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await feedingSchedule.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Feeding Schedule details updated',
            data: feedingSchedule
        });

    } catch (error) {
        console.error('Error in PATCH feedingSchedules API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH feeding schedule API',
                error: error.message
            });
          } 
    }
};

module.exports = { getAllFeedingSchedules, getFeedingScheduleByID, createFeedingSchedule, updateFeedingSchedule, patchFeedingSchedule };
