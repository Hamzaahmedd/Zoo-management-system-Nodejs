'use strict';
const { Ticket, User, Price } = require('../models');

// GET all Tickets
const getAllTickets = async (req, res) => {
    try {                         
            const tickets = await Ticket.findAll({
            where: {
                status: 'Issued'
            },
            include: [
                { model: User, as: 'user' },
                { model: Price, as: 'price' }                             
            ]
        });

        if (!tickets || tickets.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Tickets',
            totalTickets: tickets.length,
            data: tickets
        });

    } catch (error) {
        console.error('Error in GET all tickets API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all tickets API',
            error: error.message
        });
    }
};

// GET Ticket by ID
const getTicketByID = async (req, res) => {
    const ticketID = req.params.id;
    if (!ticketID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const ticket = await Ticket.findByPk(ticketID, {
            include: [
                { model: User, as: 'user' },
                { model: Price, as: 'price' }
            ]
        });

        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Ticket not found.'
            });
        }

        if (ticket.status !== "Issued") {
            return res.status(403).json({
                success: false,
                message: 'Ticket is expired'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Ticket Details',
            ticketDetails: ticket
        });

    } catch (error) {
        console.error('Error in GET tickets by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET tickets by ID API',
            error: error.message
        });
    }
};

// CREATE Ticket
const createTicket = async (req, res) => {
    const { user_id, price_id, quantity, status } = req.body;

    try {
        // Check if the user_id exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'user_id not found'
            });
        }

        // Check if the price_id exists
        const price = await Price.findByPk(price_id);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'price_id not found'
            });
        }

        // Create new ticket using Sequelize create method
        const newTicket = await Ticket.create({user_id, price_id, quantity, status});

        res.status(201).json({
            success: true,
            message: 'New Ticket created',
            data: newTicket
        });

    } catch (error) {
        console.error('Error in CREATE tickets API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE ticket API',
                error: error.message
            });
          } 
    }
};

// UPDATE Ticket
const updateTicket = async (req, res) => {
    const ticketID = req.params.id;
    if (!ticketID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { user_id, price_id, quantity, status } = req.body;

    try {
        // Check if the Ticket ID exists
        const ticket = await Ticket.findByPk(ticketID);
        if (!ticket) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Ticket not found'
            });
        }

        // Check if the user_id exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'user_id not found'
            });
        }

        // Check if the price_id exists
        const price = await Price.findByPk(price_id);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'price_id not found'
            });
        }

        // Update the Ticket record using Sequelize
    await ticket.update({user_id, price_id, quantity, status});

        return res.status(200).json({
            success: true,
            message: 'Ticket details updated',
            data: ticket
        });

    } catch (error) {
        console.error('Error in UPDATE tickets API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE ticket API',
                error: error.message
            });
          } 
    }
};

// PATCH Ticket
const patchTicket = async (req, res) => {
    const ticketID = req.params.id;
    if (!ticketID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { user_id, price_id, quantity, status } = req.body;

    try {
         // Check if the Ticket ID exists
         const ticket = await Ticket.findByPk(ticketID);
         if (!ticket) {
             return res.status(404).json({
                 success: false,
                 message: 'Invalid ID. Ticket not found'
             });
         }

        const fieldsToUpdate = {};

        if (user_id) {
            // Check if the user_id exists
        const user = await User.findByPk(user_id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'user_id not found'
            });
        }

            fieldsToUpdate.user_id = user_id;
        }

        if (price_id) {
            // Check if the price_id exists
        const price = await Price.findByPk(price_id);
        if (!price) {
            return res.status(404).json({
                success: false,
                message: 'price_id not found'
            });
        }
            fieldsToUpdate.price_id = price_id;
        }
        
        if (quantity) {
            fieldsToUpdate.quantity = quantity;
        }
        
        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await ticket.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Ticket details updated',
            data: ticket
        });

    } catch (error) {
        console.error('Error in PATCH tickets API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH ticket API',
                error: error.message
            });
          } 
    }
};

// const moment = require('moment');

// // Function to check and update ticket status
// const checkAndExpireTicket = async (ticket) => {
//     const issueDate = moment(ticket.createdAt).startOf('day');
//     const currentDate = moment().startOf('day');

//     if (currentDate.isAfter(issueDate)) {
//         ticket.status = 'Expired';
//         await ticket.save();
//     }
// };

// // Example usage in your controller
// const getTicket = async (req, res) => {
//     try {
//         const ticket = await Ticket.findByPk(req.params.id);
//         if (!ticket) {
//             return res.status(404).json({ success: false, message: 'Ticket not found' });
//         }

//         // Check if the ticket should be expired
//         await checkAndExpireTicket(ticket);

//         return res.status(200).json({ success: true, data: ticket });
//     } catch (error) {
//         return res.status(500).json({ success: false, message: error.message });
//     }
// };


module.exports = { getAllTickets, getTicketByID, createTicket, updateTicket, patchTicket };
