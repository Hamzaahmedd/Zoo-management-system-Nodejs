'use strict';
const { Food_item, Type } = require('../models');

// GET all Food Items
const getAllFoodItems = async (req, res) => {
    try {                         
            const foodItems = await Food_item.findAll({
            where: {
                status: 'Available'
            },
            include: [
                { model: Type, as: 'type' }                            
            ]
        });

        if (!foodItems || foodItems.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All food items record',
            totalFoodItems: foodItems.length,
            data: foodItems
        });

    } catch (error) {
        console.error('Error in GET all foodItems API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all foodItems API',
            error: error.message
        });
    }
};

// GET FoodItem by ID
const getFoodItemByID = async (req, res) => {
    const foodItemID = req.params.id;
    if (!foodItemID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const foodItem = await Food_item.findByPk(foodItemID, {
            include: [
                { model: Type, as: 'type' } 
            ]
        });

        if (!foodItem) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Food item not found.'
            });
        }

        if (foodItem.status !== "Available") {
            return res.status(403).json({
                success: false,
                message: 'Food item is unavailable'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Food item Details',
            foodItemDetails: foodItem
        });

    } catch (error) {
        console.error('Error in GET foodItems by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET foodItems by ID API',
            error: error.message
        });
    }
};

// CREATE FoodItem
const createFoodItem = async (req, res) => {
    const { name, quantity, type_id, status } = req.body;

    try {
        // Check if the type_id exists
        const type = await Type.findByPk(type_id);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'type_id not found'
            });
        }

        const existingName = await Food_item.findOne({ where: { name } });
        if (existingName) {
            return res.status(400).json({
                success: false,
                message: 'name must be unique'
            });
        }
        
        // Create new user using Sequelize create method
        const newFoodItem = await Food_item.create({name, quantity, type_id, status});

        res.status(201).json({
            success: true,
            message: 'New Food Item created',
            data: newFoodItem
        });

    } catch (error) {
        console.error('Error in CREATE foodItems API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE foof item API',
                error: error.message
            });
          } 
    }
};

// UPDATE FoodItem
const updateFoodItem = async (req, res) => {
    const foodItemID = req.params.id;
    if (!foodItemID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name, quantity, type_id, status } = req.body;

    try {
        // Check if the food item ID exists
        const foodItem = await Food_item.findByPk(foodItemID);
        if (!foodItem) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Food item not found'
            });
        }

        // Check if the type_id exists
        const type = await Type.findByPk(type_id);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'type_id not found'
            });
        }

        if (name && name !== foodItem.name) {
            const existingFoodItem = await Food_item.findOne({ where: { name } });
            if (existingFoodItem && existingFoodItem.id !== foodItemID) {
                return res.status(400).json({
                    success: false,
                    message: 'name must be unique'
                });
            }
        }

        // Update the food item record using Sequelize
    await foodItem.update({name, quantity, type_id, status});

        return res.status(200).json({
            success: true,
            message: 'Food item details updated',
            data: foodItem
        });

    } catch (error) {
        console.error('Error in UPDATE food Item API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE food item API',
                error: error.message
            });
          } 
    }
};

// PATCH FoodItem
const patchFoodItem = async (req, res) => {
    const foodItemID = req.params.id;
    if (!foodItemID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { name, quantity, type_id, status } = req.body;

    try {
         // Check if the food item ID exists
        const foodItem = await Food_item.findByPk(foodItemID);
        if (!foodItem) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Food item not found'
            });
        }

        const fieldsToUpdate = {};

        if (name) {
            const existingFoodItem = await Food_item.findOne({ where: { name } });
            if (existingFoodItem && existingFoodItem.id !== foodItemID) {
                return res.status(400).json({
                    success: false,
                    message: 'name must be unique'
                });
            }
            fieldsToUpdate.name = name;
        }

        if (quantity) {
            fieldsToUpdate.quantity = quantity;
        }

        if (type_id) {
            // Check if the type_id exists
        const type = await Type.findByPk(type_id);
        if (!type) {
            return res.status(404).json({
                success: false,
                message: 'type_id not found'
            });
        }

            fieldsToUpdate.type_id = type_id;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await foodItem.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Food item details updated',
            data: foodItem
        });

    } catch (error) {
        console.error('Error in PATCH foodItems API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH food item',
                error: error.message
            });
          } 
    }
};

module.exports = { getAllFoodItems, getFoodItemByID, createFoodItem, updateFoodItem, patchFoodItem };
