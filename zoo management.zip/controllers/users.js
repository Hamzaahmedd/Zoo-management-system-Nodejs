'use strict';
const { User } = require('../models');
const { Op } = require('sequelize');

// GET all Users
const getAllUsers = async (req, res) => {
    try {        
        const users = await User.findAll({ where: { role: "User" }});

        if (!users || users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Users record',
            totalUsers: users.length,
            data: users
        });

    } catch (error) {
        console.error('Error in GET all users API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all users API',
            error: error.message
        });
    }
};

// GET User by ID
const getUserByID = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }

        if(user.role === "Admin" || user.role === "Staff"){
            return res.status(403).json({
                success: false,
                message: 'This API shows the data of user only'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'User Details',
            userDetails: user
        });

    } catch (error) {
        console.error('Error in GET user by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET user by ID API',
            error: error.message
        });
    }
};

// CREATE User
const createUser = async (req, res) => {
    const { name, age, role, status } = req.body;

    if (!age) {
        return res.status(400).json({
            success: false,
            message: "Age is a required field"
        });
    } 

    if(role === 'Admin' || role === 'Staff'){
        return res.status(400).json({
            success: false, 
            message: "role should be 'User' for this API"
        });
    }

    try {
        // Create new user using Sequelize create method
        const newUser = await User.create({email: null, password: null, name, age, role, status});

        res.status(201).json({
            success: true,
            message: 'New user record created',
            data: newUser
        });

    } catch (error) {
        console.error('Error in CREATE user API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE user API',
                error: error.message
            });
          } 
    }
};

// UPDATE User
const updateUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { name, age, role, status } = req.body;

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }
    
        if (!age) {
            return res.status(400).json({
                success: false,
                message: "Age is a required field"
            });
        } 
    
        if(role === 'Admin' || role === 'Staff'){
            return res.status(400).json({
                success: false, 
                message: "role should be 'User' for this API"
            });
        }

        // Update the user record using Sequelize
    await user.update({name, age, role, status});

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in UPDATE user API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE user API',
                error: error.message
            });
          } 
    }
};

// PATCH User
const patchUser = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { name, age, role, status } = req.body;

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. User record not found.'
            });
        }

        const fieldsToUpdate = {};

        if (name) {
            fieldsToUpdate.name = name;
        }

        if (age) {    
            fieldsToUpdate.age = age;
        }

        if (role) {
            if(role === 'Admin' || role === 'Staff'){
                return res.status(400).json({
                    success: false, 
                    message: "role should be 'User' for this API"
                });
            }
            fieldsToUpdate.role = role;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await user.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'User details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in PATCH user API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH user API',
                error: error.message
            });
          } 
    }
};

// GET all Admins and staff
const getAllAdminsStaff = async (req, res) => {
    try {        
        const users = await User.findAll({ where: { role: { [Op.in]: ['Admin', 'Staff']} } });

        if (!users || users.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Admins and Staff record',
            totalAdminsAndStaff: users.length,
            data: users
        });

    } catch (error) {
        console.error('Error in GET all admins/ staff API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all admin/ staff API',
            error: error.message
        });
    }
};

// GET Admin and staff by ID
const getAdminStaffByID = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Admin/ staff record not found.'
            });
        }

        if(user.role === "User"){
            return res.status(403).json({
                success: false,
                message: 'This API shows the data of admin/ staff only'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Admin/ staff Details',
            adminStaffDetails: user
        });

    } catch (error) {
        console.error('Error in GET admin/ staff by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET admin/ staff by ID API',
            error: error.message
        });
    }
};

// CREATE Admin and staff
const createAdminStaff = async (req, res) => {
    const { email, password, name, role, status } = req.body;

    const validationErrors = [];

    if (!email) {
        validationErrors.push('email is a required field');
    } 

    if (!password) {
        validationErrors.push('password is a required field');
    } 

    if (validationErrors.length > 0) {
        return res.status(400).json({
            success: false,
            message: validationErrors.join(', ')
        });
    }

    if(role === 'User'){
        return res.status(400).json({
            success: false, 
            message: "role should be either 'Admin' or 'Staff' for this API"
        });
    }

    try {
        // Create new user using Sequelize create method
        const newUser = await User.create({email, password, name, age: null,  role, status});

            return res.status(201).json({
                success: true, 
                message: 'New admin/ staff record created',
                data: newUser
            });
   

    } catch (error) {
        console.error('Error in CREATE admin/ staff API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE admin/ staff API',
                error: error.message
            });
          } 
    }
};

// UPDATE Admin and staff
const updateAdminStaff = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { email, password, name, role, status } = req.body;
    const validationErrors = [];

    if (!email) {
        validationErrors.push('email is a required field');
    } 

    if (!password) {
        validationErrors.push('password is a required field');
    } 

    if (validationErrors.length > 0) {
        return res.status(400).json({
            success: false,
            message: validationErrors.join(', ')
        });
    }

    if(role === 'User'){
        return res.status(400).json({
            success: false, 
            message: "role should be either 'Admin' or 'Staff' for this API"
        });
    }

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Admin/ staff record not found.'
            });
        }
    
        // Update the user record using Sequelize
    await user.update({email, password, name, role, status});

        return res.status(200).json({
            success: true,
            message: 'Admin/ staff details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in UPDATE admin/ staff API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE admin/ staff API',
                error: error.message
            });
          } 
    }
};

// PATCH Admin and staff
const patchAdminStaff = async (req, res) => {
    const userID = req.params.id;
    if (!userID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { email, password, name, role, status } = req.body;

    try {
        const user = await User.findByPk(userID);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Admin/ Staff record not found.'
            });
        }

        const fieldsToUpdate = {};

        
        if (email) {
            fieldsToUpdate.email = email;
        }

        if (password) {
            fieldsToUpdate.password = password;
        }

        if (name) {
            fieldsToUpdate.name = name;
        }

        if (role) {
            if(role === 'User'){    
                return res.status(400).json({
                    success: false, 
                    message: "role should be either 'Admin' or 'Staff' for this API"
                });
            }
            fieldsToUpdate.role = role;
        }

        if (status) {
            fieldsToUpdate.status = status;
        }

        // Perform partial update using Sequelize update method
        await user.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Admin/ staff details updated',
            data: user
        });

    } catch (error) {
        console.error('Error in PATCH admin/ staff API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH admin/ staff API',
                error: error.message
            });
          } 
    }
};

module.exports = { getAllUsers, getUserByID, createUser, updateUser, patchUser, getAllAdminsStaff, 
    getAdminStaffByID, createAdminStaff, updateAdminStaff, patchAdminStaff };