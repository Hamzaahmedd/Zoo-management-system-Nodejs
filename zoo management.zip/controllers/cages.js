'use strict';
const { Cage } = require('../models');

// GET all Cages
const getAllCages = async (req, res) => {
    try {        
        const cages = await Cage.findAll();

        if (!cages || cages.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No records found'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'All Cages record',
            totalCages: cages.length,
            data: cages
        });

    } catch (error) {
        console.error('Error in GET all cages API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET all cages API',
            error: error.message
        });
    }
};

// GET cage by ID
const getCageByID = async (req, res) => {
    const cageID = req.params.id;
    if (!cageID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const cage = await Cage.findByPk(cageID);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Cage record not found.'
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Cage Details',
            cageDetails: cage
        });

    } catch (error) {
        console.error('Error in GET cage by ID API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in GET cage by ID API',
            error: error.message
        });
    }
};

// CREATE Cage
const createCage = async (req, res) => {
    const { cage_number, capacity } = req.body;

    try {
        // Check if a cage with the same cage_number already exists
        const existingCage = await Cage.findOne({ where: { cage_number } });
        if (existingCage) {
            return res.status(400).json({
                success: false,
                message: 'cage_number must be unique'
            });
        }

        // Create new cage using Sequelize create method
        const newCage = await Cage.create({cage_number, capacity});

        res.status(201).json({
            success: true,
            message: 'New cage record created',
            data: newCage
        });

    } catch (error) {
        console.error('Error in CREATE cage API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in CREATE cage API',
                error: error.message
            });
          } 
    }
};

// UPDATE Cage
const updateCage = async (req, res) => {
    const cageID = req.params.id;
    if (!cageID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    const { cage_number, capacity } = req.body;
    
    try {
        const cage = await Cage.findByPk(cageID);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Cage record not found.'
            });
        }
    
        // Check if the new cage_number already exists, excluding the current cage
        if (cage_number && cage_number !== cage.cage_number) {
            const existingCage = await Cage.findOne({ where: { cage_number } });
            if (existingCage && existingCage.id !== cage.id) {
                return res.status(400).json({
                    success: false,
                    message: 'cage_number must be unique'
                });
            }
        }

        // Update the cage record using Sequelize
    await cage.update({cage_number, capacity});

        return res.status(200).json({
            success: true,
            message: 'Cage details updated',
            data: cage
        });

    } catch (error) {
        console.error('Error in UPDATE cage API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in UPDATE cage API',
                error: error.message
            });
          } 
    }
};

// PATCH Cage
const patchCage = async (req, res) => {
    const cageID = req.params.id;
    if (!cageID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }
    const { cage_number, capacity } = req.body;

    try {
        const cage = await Cage.findByPk(cageID);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Cage record not found.'
            });
        }

        const fieldsToUpdate = {};

        if (cage_number) {
            // Check if the new cage_number already exists, excluding the current cage
            const existingCage = await Cage.findOne({ where: { cage_number } });
            if (existingCage && existingCage.id !== cageID) {
                return res.status(400).json({
                    success: false,
                    message: 'cage_number must be unique'
                });
            }
            fieldsToUpdate.cage_number = cage_number;
        }

        if (capacity) {
            fieldsToUpdate.capacity = capacity;
        }

        // Perform partial update using Sequelize update method
        await cage.update(fieldsToUpdate);

        return res.status(200).json({
            success: true,
            message: 'Cage details updated',
            data: cage
        });

    } catch (error) {
        console.error('Error in PATCH cage API:', error);
        if (error.name === 'SequelizeValidationError') {
            res.status(400).json({
              success: false,
              message: error.errors.map(e => e.message).join(', ')
            });
          } else{
            return res.status(500).json({
                success: false,
                message: 'Error in PATCH cage API',
                error: error.message
            });
          } 
    }
};

// DELETE Cage
const deleteCage = async (req, res) => {
    const cageID = req.params.id;
    
    if (!cageID) {
        return res.status(400).json({
            success: false,
            message: 'Please provide ID'
        });
    }

    try {
        const cage = await Cage.findByPk(cageID);
        if (!cage) {
            return res.status(404).json({
                success: false,
                message: 'Invalid ID. Cage record not found.'
            });
        }

        await cage.destroy();
        return res.status(200).json({
            success: true,
            message: 'Cage record deleted successfully'
        });

    } catch (error) {
        console.error('Error in DELETE cage API:', error);
        return res.status(500).json({
            success: false,
            message: 'Error in DELETE cage API',
            error: error.message
        });
    }
};

module.exports = { getAllCages, getCageByID, createCage, updateCage, patchCage, deleteCage };