'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Price extends Model {
    static associate(models) {
      const Ticket = models.Ticket;
      Price.hasMany(Ticket, {foreignKey: "price_id"});
    }
  }
  Price.init({
    value: {
      allowNull: false,
      unique: {
        args: true,
        msg: 'value must be unique'
      },
      type: DataTypes.DECIMAL(10, 2),
      validate:{
        notNull: {
          msg: 'value is a required field'
        },
        notEmpty: {
          msg: 'value cannot be empty'
        },
        isDecimal: {
          msg: 'value must be a decimal number upto 2 decimal place'
        },
        min: {  
          args: 0.01,
          msg: 'value must be at least 0.01', 
        }, 
        isCorrectFormat(value) {
          if (!/^\d+\.\d{2}$/.test(value.toString())) {
              throw new Error('value must be a decimal number with exactly two decimal places');
          }
      }
      }
    }
  }, {
    sequelize,
    modelName: 'Price',
    tableName: 'prices',
    timestamps: true
  });
  return Price;
};