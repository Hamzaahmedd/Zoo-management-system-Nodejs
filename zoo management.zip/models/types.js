'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Type extends Model {
    static associate(models) {
      const Food_item = models.Food_item;
      Type.hasMany(Food_item, {foreignKey: "type_id"});
    }
  }
  Type.init({ 
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      unique: {
        args: true,
        msg: 'name must be unique'
      },
      validate: {
        notNull: {
          msg: 'name is a required field'
        },
        notEmpty: {
          msg: 'name cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "name should be a string value"
        },
      }
    },
  }, {
    sequelize,
    modelName: 'Type',
    tableName: 'types',
    timestamps: true
  });
  return Type;
};