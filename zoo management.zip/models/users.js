'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    static associate(models) {
      const Ticket = models.Ticket;
      const Animal = models.Animal;
      User.hasMany(Ticket, { foreignKey: 'user_id'});
      User.hasMany(Animal, { foreignKey: "admin_id"});
      User.hasMany(Animal, { foreignKey: "staff_id"});
    }
  }
  
  User.init({
    email: {
      type: DataTypes.STRING,
      unique: {
        args: true,
        msg: 'email must be unique'
      },
      validate: {
        notEmpty: {
          msg: 'email cannot be empty'
        },
        isEmail: {
          args: true,
          msg: 'Please provide a valid email address (e.g., example@example.com)'
        }
      }
    },
    password: {
      type: DataTypes.STRING,
      validate: {
        notEmpty: {
          msg: 'password cannot be empty'
        },
        len: {
          args: [8, 100],
          msg: 'password must be between 8 and 100 characters long'
        },
        is: {
          args: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,100}$/,
          msg: 'password must include at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&)'
        }
      }
    },
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notNull: {
          msg: 'name is a required field'
        },
        notEmpty: {
          msg: 'name cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "name should be a string value"
        },
      }
    },
    age: {
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: {
          msg: 'age cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'age must be an integer' 
        },
        min: {
          args: [1],
          msg: 'age cannot be less than 1' 
        },
      }
    },
    role: {
      allowNull: false,
      type: DataTypes.ENUM("Admin", "Staff", "User"),
      validate: {
        notNull: {
          msg: 'role is a required field'
        },
        notEmpty: {
          msg: 'role cannot be empty'
        },
        isIn: {
          args: [["Admin", "Staff", "User"]], msg: "role should be 'Admin', 'Staff' or 'User'"
      }
    }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Active", "Inactive"),
      validate: {
        notNull: {
          msg: 'status is a required field'
        },
        notEmpty: {
          msg: 'status cannot be empty'
        },
        isIn: {
          args: [["Active", "Inactive"]], msg: "status should be 'Active' or 'Inactive'"
      }
    }
    },
  }, {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    timestamps: true
  });
  return User;
};