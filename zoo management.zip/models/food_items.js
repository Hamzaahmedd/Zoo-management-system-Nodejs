'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Food_item extends Model {
    static associate(models) {
      const Type = models.Type;
      const Feeding_schedule = models.Feeding_schedule;
      Food_item.belongsTo(Type, {as: "type", foreignKey: "type_id"});
      Food_item.belongsTo(Feeding_schedule, {as: "food", foreignKey: "food_id"});
    }
  }
  Food_item.init({
    name: {
      allowNull: false,
      unique: {
        args: true,
        msg: 'name must be unique'
      },
      type: DataTypes.STRING,
      validate: {
        notNull: {
          msg: 'name is a required field'
        },
        notEmpty: {
          msg: 'name cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "name should be a string value"
        }
      } 
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'quantity is a required field'
        },
        notEmpty: {
          msg: 'quantity cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'quantity must be an integer' 
        },
        min: {
          args: [1],
          msg: 'quantity cannot be less than 1' 
        },
      }
    },
    type_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'type_id is a required field'
        },
        notEmpty: {
          msg: 'type_id cannot be empty'
        },
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Available", "Unavailable"),
      validate: {
        notNull: {
          msg: 'status is a required field'
        },
        notEmpty: {
          msg: 'status cannot be empty'
        },
        isIn: {
          args: [["Available", "Unavailable"]], msg: "status should be 'Available' or 'Unavailable'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Food_item',
    tableName: 'food_items',
    underscored: true,
    timestamps: true
  });
  return Food_item;
};