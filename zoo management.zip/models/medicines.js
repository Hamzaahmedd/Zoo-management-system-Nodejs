'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Medicine extends Model {
    static associate(models) {
      const Animal = models.Animal;
      Medicine.hasMany(Animal, {foreignKey: "medicine_id"});
    }
  }
  Medicine.init({
    name: {
      allowNull: false,
      unique: {
        args: true,
        msg: 'name must be unique'
      },
      type: DataTypes.STRING,
      validate: {
        notNull: {
          msg: 'name is a required field'
        },
        notEmpty: {
          msg: 'name cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "name should be a string value"
        }
      }
    },
    purpose: {
      allowNull: false,
      unique: {
        args: true,
        msg: 'purpose must be unique'
      },
      type: DataTypes.TEXT,
      validate: {
        notNull: {
          msg: 'purpose is a required field'
        },
        notEmpty: {
          msg: 'purpose cannot be empty'
        },
        len: {
          args: [1, 1000],
          msg: 'purpose must be between 1 and 1000 characters'
        }
      }
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'quantity is a required field'
        },
        notEmpty: {
          msg: 'quantity cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'quantity must be an integer' 
        },
        min: {
          args: [1],
          msg: 'quantity cannot be less than 1' 
        },
      }
    },
  }, {
    sequelize,
    modelName: 'Medicine',
    tableName: 'medicines',
    timestamps: true
  });
  return Medicine;
};