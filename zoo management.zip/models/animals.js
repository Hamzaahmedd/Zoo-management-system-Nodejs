'use strict';
const {Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Animal extends Model {
    static associate(models) {
      const Medicine = models.Medicine;
      const Cage = models.Cage;
      const Feeding_schedule = models.Feeding_schedule;
      const User = models.User;
      Animal.belongsTo(Medicine, {as: "medicine", foreignKey: 'medicine_id'});
      Animal.hasMany(Feeding_schedule, {foreignKey: "animal_id"});
      Animal.belongsTo(User, {as: "admin", foreignKey: 'admin_id'});
      Animal.belongsTo(User, {as: "staff", foreignKey: 'staff_id'});
      Animal.belongsTo(Cage, {as: "cage", foreignKey: "cage_id"});
    }
  }
  Animal.init({
    name: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notNull: {
          msg: 'name is a required field'
        },
        notEmpty: {
          msg: 'name cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "name should be a string value"
        },
      }
    },
    species: {
      allowNull: false,
      type: DataTypes.STRING,
      validate: {
        notNull: {
          msg: 'species is a required field'
        },
        notEmpty: {
          msg: 'species cannot be empty'
        },
        is: {
          args: ["^[a-zA-Z ]+$"],
          msg: "species should be a string value"
        },
      }
    },
    cage_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'cage_id is a required field'
        },
        notEmpty: {
          msg: 'cage_id cannot be empty'
        },
      }
    },
    medicine_id: {
      type: DataTypes.INTEGER,
      validate: {
        notEmpty: {
          msg: 'medicine_id cannot be empty'
        },
      }
    },
    admin_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'admin_id is a required field'
        },
        notEmpty: {
          msg: 'admin_id cannot be empty'
        },
      }
    },
    staff_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'staff_id is a required field'
        },
        notEmpty: {
          msg: 'staff_id cannot be empty'
        },
      }
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'quantity is a required field'
        },
        notEmpty: {
          msg: 'quantity cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'quantity must be an integer' 
        },
        min: {
          args: [1],
          msg: 'quantity cannot be less than 1' 
        },
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Alive", "Dead"),
      validate: {
        notNull: {
          msg: 'status is a required field'
        },
        notEmpty: {
          msg: 'status cannot be empty'
        },
        isIn: {
          args: [["Alive", "Dead"]], msg: "status should be 'Alive' or 'Dead'"
      }
    }
    }
  }, {
    sequelize,
    modelName: 'Animal',
    tableName: 'animals',
    timestamps: true
  });
  return Animal;
};