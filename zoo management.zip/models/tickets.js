'use strict';
const { Model} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Ticket extends Model {
    static associate(models) {
      const User = models.User;
      const Price = models.Price;
      Ticket.belongsTo(User, {as: "user", foreignKey: "user_id"});
      Ticket.belongsTo(Price, {as: "price", foreignKey: "price_id"});
    }
  }
  Ticket.init({
    user_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'staff_id is a required field'
        },
        notEmpty: {
          msg: 'staff_id cannot be empty'
        },
      }
    },
    price_id: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'staff_id is a required field'
        },
        notEmpty: {
          msg: 'staff_id cannot be empty'
        },
      }
    },
    quantity: {
      allowNull: false,
      type: DataTypes.INTEGER,
      validate: {
        notNull: {
          msg: 'quantity is a required field'
        },
        notEmpty: {
          msg: 'quantity cannot be empty'
        },
        isInt: {
          args: true,
          msg: 'quantity must be an integer' 
        },
        min: {
          args: [1],
          msg: 'quantity cannot be less than 1' 
        },
      }
    },
    status: {
      allowNull: false,
      type: DataTypes.ENUM("Issued", "Expired"),
      validate: {
        notNull: {
          msg: 'status is a required field'
        },
        notEmpty: {
          msg: 'status cannot be empty'
        },
        isIn: {
          args: [["Issued", "Expired"]], msg: "status should be 'Issued' or 'Expired'"
      }
    }
  }
  }, {
    sequelize,
    modelName: 'Ticket',
    tableName: 'tickets',
    timestamps: true
  });
  return Ticket;
};