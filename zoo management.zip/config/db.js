const mysql = require('mysql2/promise');
const mySqlPool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'zoo_db'
});

module.exports = mySqlPool;