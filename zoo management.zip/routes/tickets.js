const express = require('express');
const { getAllTickets, getTicketByID, createTicket, updateTicket, patchTicket } = require('../controllers/tickets');

//Router object
const router = express.Router();

//GET all Tickets
router.get('/getall', getAllTickets);

//GET Ticket by ID
router.get('/get/:id', getTicketByID);

//CREATE Ticket
router.post('/create', createTicket);

//UPDATE Ticket
router.put('/update/:id', updateTicket);

//PATCH Ticket
router.patch('/patch/:id', patchTicket);

module.exports = router;