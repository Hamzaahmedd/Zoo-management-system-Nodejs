const express = require('express');
const {getAllUsers, getUserByID, createUser, updateUser, patchUser, getAllAdminsStaff, getAdminStaffByID, createAdminStaff, updateAdminStaff, patchAdminStaff } = require('../controllers/users');

//Router object
const router = express.Router();

//GET all users
router.get('/getall', getAllUsers);

//GET user by ID
router.get('/get/:id', getUserByID);

//CREATE user
router.post('/create', createUser);

//UPDATE user
router.put('/update/:id', updateUser);

//PATCH user
router.patch('/patch/:id', patchUser);

//GET all admin staff
router.get('/getalladminstaff', getAllAdminsStaff);

//GET admin staff by ID
router.get('/getadminstaff/:id', getAdminStaffByID);

//CREATE admin staff
router.post('/createadminstaff', createAdminStaff);

//UPDATE admin staff
router.put('/updateadminstaff/:id', updateAdminStaff);

//PATCH admin staff
router.patch('/patchadminstaff/:id', patchAdminStaff);

module.exports = router;