const express = require('express');
const {getAllUsers, getUserByID, createUser, updateUser, patchUser } = require('../controllers/users');

//Router object
const router = express.Router();

//GET all users
router.get('/getall', getAllUsers);

//GET user by ID
router.get('/get/:id', getUserByID);

//CREATE user
router.post('/create', createUser);

//UPDATE user
router.put('/update/:id', updateUser);

//PATCH user
router.patch('/patch/:id', patchUser);

module.exports = router;