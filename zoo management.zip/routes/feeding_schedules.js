const express = require('express');
const { getAllFeedingSchedules, getFeedingScheduleByID, createFeedingSchedule, updateFeedingSchedule, patchFeedingSchedule } 
= require('../controllers/feeding_schedules');

//Router object
const router = express.Router();

//GET all FeedingSchedules
router.get('/getall', getAllFeedingSchedules);

//GET FeedingSchedule by ID
router.get('/get/:id', getFeedingScheduleByID);

//CREATE FeedingSchedule
router.post('/create', createFeedingSchedule);

//UPDATE FeedingSchedule
router.put('/update/:id', updateFeedingSchedule);

//PATCH FeedingSchedule
router.patch('/patch/:id', patchFeedingSchedule);

module.exports = router;