const express = require('express');
const { getAllMedicines, getMedicineByID, createMedicine, updateMedicine, patchMedicine, deleteMedicine } = require('../controllers/medicines');

//Router object
const router = express.Router();

//GET all Medicines
router.get('/getall', getAllMedicines);

//GET Medicine by ID
router.get('/get/:id', getMedicineByID);

//CREATE Medicine
router.post('/create', createMedicine);

//UPDATE Medicine
router.put('/update/:id', updateMedicine);

//PATCH Medicine
router.patch('/patch/:id', patchMedicine);

//DELETE Medicine
router.delete('/delete/:id', deleteMedicine);

module.exports = router;