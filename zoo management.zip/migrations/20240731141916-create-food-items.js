'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('food_items', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        allowNull: false,
        unique: true, // Ensure that each food item name is unique
        type: Sequelize.STRING
      },
      quantity: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      type_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'types', // Ensure this matches your actual food types table name
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      status: {
        allowNull: false,
        type: Sequelize.ENUM("Available", "Unavailable")
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE  
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('food_items');
  }
};
