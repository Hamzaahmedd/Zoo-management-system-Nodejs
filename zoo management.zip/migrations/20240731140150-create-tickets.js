'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('tickets', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      user_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'users', // Table name for users
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      price_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'prices', // Table name for prices
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      quantity: {
        allowNull: false,
        type: Sequelize.INTEGER,
      },
      status: {
        allowNull: false,
        type: Sequelize.ENUM("Issued", "Expired"),
        validate: {
          notNull: {
            msg: 'Status is required'
          },
          isIn: {
            args: [["Issued", "Expired"]],
            msg: "Status must be either 'Issued' or 'Expired'"
          }
        }
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('tickets');
  }
};
