'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('feeding_schedules', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      animal_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'animals', 
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      time: {
        allowNull: false,
        type: Sequelize.TIME 
      },
      food_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'food_items', // Ensure this matches your actual food table name
          key: 'id'
        },
        onUpdate: 'CASCADE', 
        onDelete: 'CASCADE'  
      },
      status: {
        allowNull: false,
        type: Sequelize.ENUM("Pending", "Completed")
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('feeding_schedules');
  }
};