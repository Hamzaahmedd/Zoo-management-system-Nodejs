'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('animals', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        allowNull: false,
        type: Sequelize.STRING
      },
      species: {
        allowNull: false,
        type: Sequelize.STRING
      },
      cage_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'cages', // Table name for cages
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      medicine_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'medicines', // Table name for medicines
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      admin_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'users', // Table name for admins
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      staff_id: {
        allowNull: false,
        type: Sequelize.INTEGER,
        references: {
          model: 'users', // Table name for staff
          key: 'id'
        },
        onUpdate: 'CASCADE', // Prevent updates if there are related records
        onDelete: 'CASCADE'  // Prevent deletions if there are related records
      },
      quantity: {
        allowNull: false,
        type: Sequelize.INTEGER
      },
      status: {
        allowNull: false,
        type: Sequelize.ENUM("Alive", "Dead")
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('animals');
  }
};
