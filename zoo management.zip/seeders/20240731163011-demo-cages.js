'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const cagesData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('cages', cagesData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('cages', null, {});
  }
};
