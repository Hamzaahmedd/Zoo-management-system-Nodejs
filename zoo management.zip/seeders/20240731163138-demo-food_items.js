'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const food_itemsData = [
      {name: "Lettuce", quantity: 1, type_id: 1, status: "Available"},

    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('food_items', food_itemsData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('food_items', null, {});
  }
};
