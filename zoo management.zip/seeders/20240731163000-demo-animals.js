'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const animalsData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('animals', animalsData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('animals', null, {});
  }
};
