'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const pricesData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('prices', pricesData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('prices', null, {});
  }
};
