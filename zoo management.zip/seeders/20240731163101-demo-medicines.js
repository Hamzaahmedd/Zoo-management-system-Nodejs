'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const medicinesData = [
      {}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('medicines', medicinesData, {});
  },

  async down (queryInterface, Sequelize) {
   // Remove inserted data if needed
   await queryInterface.bulkDelete('medicines', null, {});
  }
};
