'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const typesData = [
      {name: "Leafy Greens"}
    ];

    // Perform bulk insert
    await queryInterface.bulkInsert('types', typesData, {});
  },

  async down (queryInterface, Sequelize) {
    // Remove inserted data if needed
   await queryInterface.bulkDelete('types', null, {});
  }
};
